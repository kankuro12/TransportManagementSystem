﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomControls
{
   public class customargs:EventArgs
    {
        public dynamic data { get; set; }
    }
}
